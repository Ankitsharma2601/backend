package com.infy.ekart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EK_SELLER_FEEDBACK")
public class SellerFeedback {

	@Id
	@Column(name="FEEDBACK_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer feedbackId;
	
	@Column(name = "SELLER_EMAIL_ID ")
	private String sellerId;
	
	@Column(name="CUSTOMER_EMAIL_ID")
	private String custId;
	
	@Column(name="PRODUCT_DELIVERY_SPEED")
	private Double productDeliverySpeed;
	
	@Column(name="PRODUCT_CONDITION")
	private Double productCondition;
	
	@Column(name="PRODUCT_PACKAGING")
	private Double productPakaging;

	public Integer getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getEmailId() {
		return custId;
	}

	public void setEmailId(String custId) {
		this.custId = custId;
	}

	public Double getProductDeliverySpeed() {
		return productDeliverySpeed;
	}

	public void setProductDeliverySpeed(Double productDeliverySpeed) {
		this.productDeliverySpeed = productDeliverySpeed;
	}

	public Double getProductCondition() {
		return productCondition;
	}

	public void setProductCondition(Double productCondition) {
		this.productCondition = productCondition;
	}

	public Double getProductPakaging() {
		return productPakaging;
	}

	public void setProductPakaging(Double productPakaging) {
		this.productPakaging = productPakaging;
	}
	
	
	
}
