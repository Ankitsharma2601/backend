package com.infy.ekart.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.model.Order;
import com.infy.ekart.model.OrderStatus;
import com.infy.ekart.model.Product;
import com.infy.ekart.dao.SellerDAO;
import com.infy.ekart.dao.SellerOrderDAO;
import com.infy.ekart.entity.CustomerEntity;
import com.infy.ekart.entity.OrderEntity;
import com.infy.ekart.repository.CustomerRepository;


@Service(value = "viewOrderService")
@Transactional
public class ViewOrderServiceImpl implements ViewOrderService {
	

	@Autowired
	private CustomerRepository customerRepository;
	
	public List<Order> viewOrders(String customerEmailId) throws Exception {
		
		CustomerEntity customer = customerRepository.findByEmailId(customerEmailId);
		if(customer==null) {
			throw new Exception("Service.CUSTOMER_NOT_FOUND");
		}
		
		List<OrderEntity> orderList = customer.getOrders();
		if(orderList.isEmpty())
			throw new Exception("ViewOrderService.NO_ORDER_FOUND_WITH_GIVEN_EMAIL");
		List<Order> orderDTOs = new ArrayList<Order>();
		for(OrderEntity order : orderList) {
			Order orderDTO = new Order();
			orderDTO.setAddressId(order.getAddressId());

			orderDTO.setDataOfDelivery(order.getDataOfDelivery());
			orderDTO.setDateOfOrder(order.getDateOfOrder());
			orderDTO.setOrderId(order.getOrderId());
			orderDTO.setOrderNumber(order.getOrderNumber());
			orderDTO.setPaymentThrough(order.getPaymentThrough());
			orderDTO.setQuantity(order.getQuantity());
			orderDTO.setTotalPrice(order.getTotalPrice());
			orderDTO.setOrderStatus(order.getOrderStatus().toString());
			
			
			Product pDTO= new Product();
			pDTO.setProductId(order.getProductEntity().getProductId());
			pDTO.setName(order.getProductEntity().getName());
			pDTO.setBrand(order.getProductEntity().getBrand());
			pDTO.setCategory(order.getProductEntity().getCategory());
			pDTO.setDescription(order.getProductEntity().getDescription());
			pDTO.setSellerEmailId(order.getProductEntity().getSellerId());
			orderDTO.setProduct(pDTO);
			orderDTOs.add(orderDTO);
		}
		
		return orderDTOs;
		
	
		
	}
}
