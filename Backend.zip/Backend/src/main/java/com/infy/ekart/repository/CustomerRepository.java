package com.infy.ekart.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.CustomerEntity;

public interface CustomerRepository extends CrudRepository<CustomerEntity, String> {

	List<CustomerEntity> findByPhoneNumber(String phoneNumber);
	
	// added this method
	CustomerEntity findByEmailId(String emailId);

}
