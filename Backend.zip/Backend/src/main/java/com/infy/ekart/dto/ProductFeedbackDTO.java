package com.infy.ekart.dto;

import javax.validation.constraints.NotNull;

public class ProductFeedbackDTO {
	
	private Integer feedbackId;
	private Integer productId;
	private String emailId;
	@NotNull(message = "{field.absent}")
	private Double productSatisfaction;
	@NotNull(message = "{field.absent}")
	private Double productDesrMatch;
	@NotNull(message = "{field.absent}")
	private Double productRecommendation;
	
	
	public Integer getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Double getProductSatisfaction() {
		return productSatisfaction;
	}
	public void setProductSatisfaction(Double productSatisfaction) {
		this.productSatisfaction = productSatisfaction;
	}
	public Double getProductDesrMatch() {
		return productDesrMatch;
	}
	public void setProductDesrMatch(Double productDesrMatch) {
		this.productDesrMatch = productDesrMatch;
	}
	public Double getProductRecommendation() {
		return productRecommendation;
	}
	public void setProductRecommendation(Double productRecommendation) {
		this.productRecommendation = productRecommendation;
	}
		
	

}
