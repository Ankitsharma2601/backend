package com.infy.ekart.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.ProductFeedbackDTO;
import com.infy.ekart.service.ProductFeedbackService;

@CrossOrigin
@RestController
@RequestMapping(value = "/product-feedback-api")
@Validated
public class ProductFeedbackAPI {
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private ProductFeedbackService productFeedbackService;
	
	@GetMapping(value = "/feedback/{email}/{productId}")
	public ResponseEntity<Boolean> checkFeedback(@PathVariable("email")String email,
			@PathVariable("productId")Integer productId)
			throws Exception{
		
		Boolean check = productFeedbackService.checkFeedback(email, productId);
		return new ResponseEntity<>(check,HttpStatus.OK);
	}
	
	@PostMapping(value = "/submit-feedback/{email}/{productId}")
	public ResponseEntity<String> submitFeedback(@Valid @RequestBody ProductFeedbackDTO productFeedbackDTO,
			@PathVariable("email") String email,@PathVariable("productId") Integer productId) throws Exception{
		
		Integer feedbackId = productFeedbackService.submitNewFeedback(productFeedbackDTO, email, productId);
		
		String message = environment.getProperty("ProductFeedbackAPI.SUBMIT_FEEDBACK_SUCCESS") + feedbackId;
		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

}
