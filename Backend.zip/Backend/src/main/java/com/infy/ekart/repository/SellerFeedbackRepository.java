package com.infy.ekart.repository;



import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infy.ekart.entity.SellerFeedback;

public interface SellerFeedbackRepository extends CrudRepository<SellerFeedback, Integer> {

	
	@Query("select f from SellerFeedback f where f.custId = :custId and f.sellerId = :sellerId")
	List<SellerFeedback> checkExistingFeedback(@Param("custId") String custId, @Param("sellerId") String sellerId);
	
	

}
