package com.infy.ekart.api;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.model.Order;
import com.infy.ekart.service.ViewOrderService;

@CrossOrigin
@RestController
@RequestMapping(value = "/view-orders-api")
@Validated
public class ViewOrderAPI {

	@Autowired
	ViewOrderService viewOrderService;



	static Log logger = LogFactory.getLog(ViewOrderAPI.class);

	@GetMapping(value = "/view-orders/{customerEmailId}")
	public ResponseEntity<List<Order>> viewOrders(@PathVariable String customerEmailId)
			throws Exception {


		List<Order> orderDTOs = viewOrderService.viewOrders(customerEmailId);

		return new ResponseEntity<>(orderDTOs, HttpStatus.OK);
	}
}
