package com.infy.ekart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EK_PRODUCT_FEEDBACK")
public class ProductFeedback {
	
	@Id
	@Column(name="FEEDBACK_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer feedbackId;
	
	@Column(name = "PRODUCT_ID")
	private Integer productId;
	
	@Column(name="CUSTOMER_EMAIL_ID")
	private String emailId;
	
	@Column(name="PRODUCT_SATISFACTION")
	private Double productSatisfaction;
	
	@Column(name="PRODUCT_DSCR_MATCH")
	private Double productDesrMatch;
	
	@Column(name="PRODUCT_RECOMMENDATION")
	private Double productRecommendation;

	public Integer getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Double getProductSatisfaction() {
		return productSatisfaction;
	}

	public void setProductSatisfaction(Double productSatisfaction) {
		this.productSatisfaction = productSatisfaction;
	}

	public Double getProductDesrMatch() {
		return productDesrMatch;
	}

	public void setProductDesrMatch(Double productDesrMatch) {
		this.productDesrMatch = productDesrMatch;
	}

	public Double getProductRecommendation() {
		return productRecommendation;
	}

	public void setProductRecommendation(Double productRecommendation) {
		this.productRecommendation = productRecommendation;
	}
	
	
	

}
