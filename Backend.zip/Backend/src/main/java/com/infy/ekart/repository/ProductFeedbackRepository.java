package com.infy.ekart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infy.ekart.entity.ProductFeedback;

public interface ProductFeedbackRepository extends CrudRepository<ProductFeedback, Integer>{
	
	@Query("select f from ProductFeedback f where f.emailId = :email and f.productId = :productId")
	List<ProductFeedback> checkExistingFeedback(@Param("email") String email, @Param("productId") Integer productId);

	
	List<ProductFeedback> findByEmailId(String emailId);
}
