package com.infy.ekart.service;

import com.infy.ekart.dto.ProductFeedbackDTO;


public interface ProductFeedbackService {
	
	Boolean checkFeedback(String email, Integer productId) throws Exception;

	Integer submitNewFeedback(ProductFeedbackDTO productFeedbackDTO, String email,Integer productId) throws Exception;
}
