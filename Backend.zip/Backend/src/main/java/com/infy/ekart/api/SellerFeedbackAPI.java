package com.infy.ekart.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.SellerFeedbackDTO;
import com.infy.ekart.service.SellerFeedbackService;

@CrossOrigin
@RestController
@RequestMapping(value = "/seller-feedback-api")
@Validated
public class SellerFeedbackAPI {
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private SellerFeedbackService sellerFeedbackService;
	
	@GetMapping(value = "/feedback/{custId}/{sellerId}/")
	ResponseEntity<Boolean> checkFeedback(@PathVariable("custId")String custId,
			@PathVariable("sellerId")String sellerId)
					throws Exception{
		
		Boolean check = sellerFeedbackService.checkFeedback(custId, sellerId);
		
		return new ResponseEntity<>(check,HttpStatus.OK);
	}
	
	
	@PostMapping(value = "/submit-feedback")
	public ResponseEntity<String> submitFeedback(@Valid @RequestBody SellerFeedbackDTO sellerFeedbackDTO
			) throws Exception{
		
		
		Integer feedbackId = sellerFeedbackService.submitNewFeedback(sellerFeedbackDTO);
		
		String message = environment.getProperty("SellerFeedbackAPI.SUBMIT_FEEDBACK_SUCCESS") + feedbackId;
		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

}
