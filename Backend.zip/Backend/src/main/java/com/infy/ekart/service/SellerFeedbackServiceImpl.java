package com.infy.ekart.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.SellerFeedbackDTO;
import com.infy.ekart.entity.SellerFeedback;
import com.infy.ekart.repository.SellerFeedbackRepository;



@Service(value = "SellerFeedbackService")
@Transactional
public class SellerFeedbackServiceImpl implements SellerFeedbackService{

	@Autowired
	private SellerFeedbackRepository sellerFeedbackRepository;
	
	@Override
	public Integer submitNewFeedback(SellerFeedbackDTO sellerFeedbackDTO)
			throws Exception {
		if(checkFeedback(sellerFeedbackDTO.getCustId(), sellerFeedbackDTO.getSellerId())) {
			SellerFeedback sellerFeedback = new SellerFeedback();
			
			sellerFeedback.setFeedbackId(sellerFeedbackDTO.getFeedbackId());
			sellerFeedback.setEmailId(sellerFeedbackDTO.getCustId());
			sellerFeedback.setSellerId(sellerFeedbackDTO.getSellerId());
			sellerFeedback.setProductCondition(sellerFeedbackDTO.getProductCondition());
			sellerFeedback.setProductDeliverySpeed(sellerFeedbackDTO.getProductDeliverySpeed());
			sellerFeedback.setProductPakaging(sellerFeedbackDTO.getProductPakaging());
			
			SellerFeedback feedbackFromDB = sellerFeedbackRepository.save(sellerFeedback);
			
			
			return feedbackFromDB.getFeedbackId();
		}
		else {
			throw new Exception("SellerFeedbackService.FEEDBACK_ALREADY_PRESENT");
		}
	}


	@Override
	public Boolean checkFeedback(String custId, String sellerId) throws Exception {

		List<SellerFeedback> sellerFeedback = sellerFeedbackRepository.checkExistingFeedback(custId, sellerId);
		
		if(sellerFeedback.isEmpty()) {
			return true;	
		}
		else {
			
			throw new Exception("SellerFeedbackService.FEEDBACK_ALREADY_PRESENT");
		}
			
	}
	
}
