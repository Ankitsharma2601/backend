package com.infy.ekart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.ProductFeedbackDTO;
import com.infy.ekart.entity.ProductFeedback;
import com.infy.ekart.repository.ProductFeedbackRepository;

@Service(value = "ProductFeedbackService")
@Transactional
public class ProductFeedbackServiceImpl implements ProductFeedbackService {
	
	@Autowired
	private ProductFeedbackRepository productFeedbackRepo;

	@Override
	public Integer submitNewFeedback(ProductFeedbackDTO productFeedbackDTO,String email, Integer productId) throws Exception {
		
		ProductFeedback productFeedback = new ProductFeedback();
		
		if(checkFeedback(email, productId)) {
		
		
		productFeedback.setEmailId(email);
		productFeedback.setProductId(productId);
		productFeedback.setProductDesrMatch(productFeedbackDTO.getProductDesrMatch());
		productFeedback.setProductRecommendation(productFeedbackDTO.getProductRecommendation());
		productFeedback.setProductSatisfaction(productFeedbackDTO.getProductSatisfaction());
		
		ProductFeedback feedbackFromDB = productFeedbackRepo.save(productFeedback);
		
		return feedbackFromDB.getFeedbackId();
		}
		else
			throw new Exception("ProductFeedbackService.FEEDBACK_ALREADY_PRESENT");
		
	}

	@Override
	public Boolean checkFeedback(String email, Integer productId) throws Exception {
		
		List<ProductFeedback> productFeedback = productFeedbackRepo.checkExistingFeedback(email, productId);
		
		if(productFeedback.isEmpty()) {
			return true;
			
		}
		else {
			throw new Exception("ProductFeedbackService.FEEDBACK_ALREADY_PRESENT");
		}
			
	}

}
