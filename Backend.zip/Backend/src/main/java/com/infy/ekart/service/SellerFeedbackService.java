package com.infy.ekart.service;

import com.infy.ekart.dto.SellerFeedbackDTO;

public interface SellerFeedbackService {
	
	//String findSeller(Integer productId) throws EKartException;
	
	Boolean checkFeedback(String custId, String sellerId) throws Exception;

	Integer submitNewFeedback(SellerFeedbackDTO sellerFeedbackDTO) throws Exception;

}
