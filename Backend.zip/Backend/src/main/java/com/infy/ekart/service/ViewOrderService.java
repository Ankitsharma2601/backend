package com.infy.ekart.service;

import java.util.List;

import com.infy.ekart.model.Order;


public interface ViewOrderService {
	public List<Order> viewOrders(String customerEmailId) throws Exception;

}
