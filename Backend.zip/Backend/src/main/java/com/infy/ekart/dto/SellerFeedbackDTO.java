package com.infy.ekart.dto;

import javax.validation.constraints.NotNull;

public class SellerFeedbackDTO {
	
	private Integer feedbackId;
	private String sellerId;
	private String custId;
	@NotNull(message = "{field.absent}")
	private Double productDeliverySpeed;
	@NotNull(message = "{field.absent}")
	private Double productCondition;
	@NotNull(message = "{field.absent}")
	private Double productPakaging;
	
	
	public Integer getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public Double getProductDeliverySpeed() {
		return productDeliverySpeed;
	}
	public void setProductDeliverySpeed(Double productDeliverySpeed) {
		this.productDeliverySpeed = productDeliverySpeed;
	}
	public Double getProductCondition() {
		return productCondition;
	}
	public void setProductCondition(Double productCondition) {
		this.productCondition = productCondition;
	}
	public Double getProductPakaging() {
		return productPakaging;
	}
	public void setProductPakaging(Double productPakaging) {
		this.productPakaging = productPakaging;
	}
	
	
	

}
